import { PlusAndMinus } from "./PlusAndMinus";



export default function SideBar(props) {

	const handleDelete = (index) => {
		const updatedItems = [...props.selectedItems];
		updatedItems.splice(index, 1); // This is to remove the item which has that specific index.
		props.setSelectedItems(updatedItems); //This is update the state of the new Array.
	};

	return (

		<div className="sideBarContainer">


		<center>

		<img style={{width:"70px"}} src="https://purepng.com/public/uploads/large/purepng.com-shopping-basketshoppingcarttrolleycarriagebuggysupermarketsbasket-1421526532727qjew3.png"/>
		<br/>
		<span style={{ color: 'tomato', fontSize: "30px", fontFamily:"monospace"}}>Basket</span>

		</center>



				{/*<span style={{ fontSize: '50px', color: 'black' }}>&#128722;</span> Basket*/}

			{props.selectedItems.map((order, index) => (
				<div key={index} style={{ marginLeft: "20px", marginBottom: "10px", display: 'flex', alignItems: 'center'}}>
					<span>-</span>
					<span style={{fontWeight: "bold", fontFamily:"monospace", fontSize: "18px", marginRight: "20px", width:"180px", textAlign:"left"}}>{order.title}</span>


					<span style={{ color: "royalblue", fontSize:"19px", fontWeight: "bold", width:"100px", textAlign:"left"}}>size:<span style={{color:"black" , fontSize:"16px"}} >{order.selectedSize}</span></span>

					<span style={{ marginLeft: '25px', marginRight:"5px",  color: "royalblue", fontSize:"19px", fontWeight: "bold"}}>Quantity </span>
					<PlusAndMinus/>
					<button onClick={() => handleDelete(index)}
					style={{ backgroundColor: 'white', border: 'none', marginLeft: '25px', padding: 0 }}>
						<span style={{ fontSize: '30px', color: 'black' }}>&#128465;</span>
					</button>
				</div>
			))}
			<hr style={{ width: "80%", textAlign: "left", marginLeft: "0" }} />

			<h3>Price: </h3>
			<h3>delivery costs: </h3>
			<h3>total price: </h3>
			<button className="checkOut">Check out</button>


		</div>

	);
}
