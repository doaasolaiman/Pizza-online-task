

export const PlusAndMinus = () => {

	const buttonsformatting = {
		width: "20px",
		borderRadius:" 100%",
		border:"1px solid royalBlue",
		textAlign: "center",
		fontSize: "16px",
		cursor:"pointer",


	}


	const [num , setNum] = React.useState (1);
		const plus = () => {
			setNum(num + 1);

		}

		const minus = () => {
			if (num > 1)
			setNum(num-1)
		}

	return (

	<div style={{width: "100px", height: "30px", padding: "7px",border:"solid 1px gray", borderRadius:"5px", display: "flex", justifyContent: "center", alignItems:"center"}}>

		<button onClick={plus} style={buttonsformatting}>+</button>
		<span style={{textAlign:"center", width: "50px"}}>{num}</span>
		<button onClick={minus} style={buttonsformatting}>-</button>

	</div>
	)
}
