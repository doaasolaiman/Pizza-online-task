export class Welcome extends React.Component {
	render() {
		return (

			<div className="header">
				<h1 style={{color:"white"}}>Pizza Online</h1>




			</div>
		)
	}

}



