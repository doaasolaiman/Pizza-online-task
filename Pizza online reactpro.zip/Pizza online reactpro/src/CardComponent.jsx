export default function Cardcomponent(props) {

	const [quantity, setQuantity] = React.useState(0);

	const handleAddToCart = (size) => {
		setQuantity(quantity + 1);
		props.addToCart({ title: props.title, size, quantity: quantity + 1 });
	};

	return (

		<div>


			<img src={props.img} alt={props.title} style={{ width: '100%', height: '220px' }} />
			<h2>{props.title}</h2>
			<p style={{ color: 'darkgray' }}>{props.desccription}</p>
			<p>Small: {props.Small}</p>
			<p>Medium: {props.Medium}</p>
			<p>Large: {props.Large}</p>
			<p style={{fontSize:'18px', color: 'gray'}}>{props.sentence}</p>
			<center>
				<button onClick={() => props.addToCart("Small")} style={{ backgroundColor: "royalblue", margin: '5px', padding: '8px', borderRadius: '5px', border: 'none', color: 'white', }}>Small</button>
				<button onClick={() => props.addToCart("Medium")} style={{ backgroundColor: "royalblue", margin: '5px', padding: '8px', borderRadius: '5px', border: 'none', color: 'white', }}>Medium</button>
				<button onClick={() => props.addToCart("Large")} style={{ backgroundColor: "royalblue", margin: '5px', padding: '8px', borderRadius: '5px', border: 'none', color: 'white', }}>Large</button>
			</center>

		</div>

	);


}
