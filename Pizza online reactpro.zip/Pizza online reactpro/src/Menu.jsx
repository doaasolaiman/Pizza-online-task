export const Menu = [

	{
		id: 1,
		img: 'https://tanospizzeria.files.wordpress.com/2022/10/pizza-on-white-wooden-table.jpg',
		title: 'pizza Tanno',
		desccription: 'pasta, with mozzarella cheesered onion and pepper',
		Small: "5.60€",
		Medium: "6.50€",
		Large: "7.80€",
		sentence: 'Add to basket:',



	},


	{
		id: 2,
		img: 'https://www.globusdoener.de/leipzig-riebeckstrasse/media/image/storage/1619864173_1152_768_2_media_image_product_133_lg_pizza-salami_jpg.jpg',
		title: 'pizza Salami',
		desccription: 'salami, onions, cheese and seasonings.',
		Small: "5.40€",
		Medium: "6.20€",
		Large: "7.40€",
		sentence: 'Add to basket:',


	},



	{
		id: 3,
		img: 'https://kitchenatics.com/wp-content/uploads/2020/09/Cheese-pizza-1.jpg',
		title: 'pizza Cheese',
		desccription: 'Parmesan, fontina, mozzarella and feta cheese',
		Small: "7.50€",
		Medium: "9.40€",
		Large: "10.20€",
		sentence: 'Add to basket:',


	},




	{
		id: 4,
		img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Pizza_Margherita_stu_spivack.jpg/1280px-Pizza_Margherita_stu_spivack.jpg',
		title: 'pizza Marghrita',
		desccription: 'tomato, fresh mozzarella, basil leaves and pepper.',
		Small: "6.50€",
		Medium: "7.00€",
		Large: "9.50€",
		sentence: 'Add to basket:',
	},


	{
		id: 5,
		img: 'https://www.realmomkitchen.com/wp-content/uploads/2013/10/Black-and-White-Pizza.jpg',
		title: 'pizza Olives',
		desccription: 'tomato sauce, fresh mozzarella,fresh balck olives.',
		Small: "5.00€",
		Medium: "6.30€",
		Large: "8.50€",
		sentence: 'Add to basket:',
	},


	{
		id: 6,
		img: 'https://images.getrecipekit.com/20230412153738-rao-s-20deep-20dish-20pizza.webp?aspect_ratio=16:9&quality=90&',
		title: 'pizza Sauce',
		desccription: 'tomato sauce, Ketchup,fresh vegetables.',
		Small: "6.20€",
		Medium: "8.40€",
		Large: "9.50€",
		sentence: 'Add to basket:',
	},

]


