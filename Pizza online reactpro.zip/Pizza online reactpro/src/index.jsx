import React from "react"
import ReactDOM from "react-dom";
import "./index.scss"
import { Welcome } from "./Logo";
import { Menu } from "./Menu";
import Cardcomponent from "./CardComponent";
import  SideBar  from "../SideBarNav";

function App() {

	const [selectedItems, setSelectedItems] = React.useState([]);



	const group1 = Menu.slice(0, 3);
	const group2 = Menu.slice(3, 6);


	const viewCardComponent = (group) =>

		group.map((element) => (

			<div className="card" key={element.id}>

				<Cardcomponent
				img={element.img}
				title={element.title}
				desccription={element.desccription}
				Small={element.Small} Medium={element.Medium} Large={element.Large} sentence={element.sentence}
				addToCart={(selectedSize) => {
					const newSelectedItem = {...element}; // Makes a copy of the selected pizza element
					// Add information about the selected size to it
					newSelectedItem.selectedSize = selectedSize;
					setSelectedItems([...selectedItems,newSelectedItem]);

				}} />
			</div>
		));


	return (
		<>
			<div style={{backgroundColor:"orange", width:"100%", marginBottom: "15px"}}><Welcome /></div>




			<div id="app">
				<div className="group" style={{ width: "25%"}}>
					{viewCardComponent(group1)}
				</div>
				<div className="group" style={{ width: "25%"}}>
					{viewCardComponent(group2)}
				</div>
			</div>

			<div className="sideBar" style={{ width: "40%", marginLeft: "20px"}}><SideBar selectedItems={selectedItems} setSelectedItems={setSelectedItems}/></div>



		</>
	);
}




window.onload = () => ReactDOM.render(<App />, document.getElementById("app"));
